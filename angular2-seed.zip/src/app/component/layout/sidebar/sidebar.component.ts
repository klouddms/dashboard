import { Component,OnInit } from '@angular/core';

@Component({
  selector: '[sidebar]',
  templateUrl: './sidebar.template.html',
  styleUrls: [ './sidebar.style.css' ],
})
export class Sidebar implements OnInit{
  ngOnInit(){

  }
}
